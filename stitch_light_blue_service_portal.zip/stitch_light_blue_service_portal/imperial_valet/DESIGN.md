---
name: Imperial Valet
colors:
  surface: '#f8f9ff'
  surface-dim: '#d0dbed'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dee9fc'
  surface-container-highest: '#d9e3f6'
  on-surface: '#121c2a'
  on-surface-variant: '#3f484a'
  inverse-surface: '#27313f'
  inverse-on-surface: '#eaf1ff'
  outline: '#6f797b'
  outline-variant: '#bfc8ca'
  surface-tint: '#1e6772'
  primary: '#00444d'
  on-primary: '#ffffff'
  primary-container: '#0d5d68'
  on-primary-container: '#92d4e0'
  inverse-primary: '#8fd1de'
  secondary: '#29676d'
  on-secondary: '#ffffff'
  secondary-container: '#b0edf4'
  on-secondary-container: '#306d73'
  tertiary: '#735c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#cca730'
  on-tertiary-container: '#4f3d00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#abedfa'
  primary-fixed-dim: '#8fd1de'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#b0edf4'
  secondary-fixed-dim: '#95d1d7'
  on-secondary-fixed: '#002023'
  on-secondary-fixed-variant: '#044f55'
  tertiary-fixed: '#ffe088'
  tertiary-fixed-dim: '#e9c349'
  on-tertiary-fixed: '#241a00'
  on-tertiary-fixed-variant: '#574500'
  background: '#f8f9ff'
  on-background: '#121c2a'
  surface-variant: '#d9e3f6'
typography:
  display-lg:
    fontFamily: Libre Caslon Text
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
  headline-lg:
    fontFamily: Libre Caslon Text
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Libre Caslon Text
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-md:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-margin: 24px
  gutter: 16px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 40px
---

## Brand & Style

The brand personality is rooted in the "Butler" archetype—distinguished, anticipatory, and impeccably reliable. This design system bridges the gap between traditional white-glove service and modern convenience. It targets high-net-worth individuals and busy professionals who value their time and demand excellence in home maintenance.

The visual style is a **Modern-Corporate** hybrid with **Tactile** accents. It utilizes ample whitespace to convey cleanliness and uses gold-accented "filigree" details sparingly to evoke luxury without feeling dated. The interface should feel "quiet"—there is no visual noise, only purposeful information delivered with elegance and comfort.

## Colors

The palette is derived from the "Mr. Butler" crest, emphasizing aquatic cleanliness and traditional prestige.

- **Primary (Deep Teal):** Used for primary actions, navigation headers, and authoritative text. It represents stability and professional depth.
- **Secondary (Light Blue):** Used for background washes, decorative surfaces, and "freshness" indicators. It provides the "airy" feel of clean linens.
- **Tertiary (Gold):** Reserved for premium status indicators, "Butler" tier services, and delicate border accents.
- **Neutral (Slate/Charcoal):** Provides grounded legibility for body text and functional icons.
- **Surface:** A warm, off-white (#FAFAF9) is used for the main background to prevent the clinical feel of pure white.

## Typography

This design system employs a high-contrast typographic pairing to signal both heritage and modern efficiency. 

**Libre Caslon Text** is the voice of the Butler. It is used for headlines and screen titles to provide an editorial, premium feel reminiscent of traditional tailoring and high-end stationery.

**Manrope** provides the functional backbone. As a modern, geometric sans-serif, it ensures maximum legibility for service lists, prices, and booking details. It is used for all body text, inputs, and button labels.

## Layout & Spacing

The layout follows a **fluid grid** model with generous padding to emphasize "Luxury through Space." 

- **Mobile:** A 4-column grid with 24px side margins. This wide margin creates a centered, focused content area that feels more premium than edge-to-edge designs.
- **Rhythm:** An 8px linear scale governs all spacing. Vertical stacks are intentionally tall (24px - 40px) to give elements room to breathe.
- **Sectioning:** Content is grouped into high-contrast cards. Horizontal scrolling (carousels) is used for service categories to maintain a clean vertical scan.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Ambient Shadows**.

- **Surfaces:** The primary background is the warm off-white. Cards and containers use pure white (#FFFFFF) to pop forward.
- **Shadows:** Use extremely soft, long-range shadows (Blur: 30px, Y: 10px) with a very low opacity teal tint (Primary @ 8%) rather than pure black. This creates an "airy" lift that mimics fabric or paper.
- **Depth:** Interactive elements (buttons, active cards) use a 1px solid border in the secondary light blue or a 0.5px gold line for premium selections, rather than heavy drop shadows.

## Shapes

The shape language is refined and "Softly Tailored."

- **Containers:** Cards and primary UI containers use a 16px (rounded-lg) corner radius. This feels approachable and comfortable, echoing the "comfort" aspect of the brand narrative.
- **Buttons:** Buttons use a slightly larger 24px radius to feel ergonomic and soft to the touch.
- **Icons:** Icons should be enclosed in circular frames or "lozenge" shapes, reminiscent of the crest in the logo. Avoid sharp corners in all iconography.

## Components

### Buttons
- **Primary:** Deep Teal background with White Manrope Bold text. Subtle gold 1px bottom border on hover/press.
- **Secondary:** Light Blue background with Deep Teal text. 
- **Premium:** Deep Teal background with Gold text and a 1px Gold border.

### Cards
- Pure white background with a 16px radius.
- Includes a subtle 0.5px border in Light Blue to define edges against the off-white background.
- Service cards feature high-resolution imagery with a "Butler's Crest" icon overlay in the corner.

### Service Chips
- Pill-shaped (32px height).
- Unselected: Light Blue background, Teal text.
- Selected: Deep Teal background, White text.

### Inputs
- Underlined style rather than fully boxed to feel more like high-end stationery. 
- Deep Teal labels in Manrope Bold (12px) floating above the line.

### Butler Status Bar
- A unique component for this design system: a slim gold-accented bar at the top of the screen showing "Your Butler is en route" or current service status, using Libre Caslon Text.