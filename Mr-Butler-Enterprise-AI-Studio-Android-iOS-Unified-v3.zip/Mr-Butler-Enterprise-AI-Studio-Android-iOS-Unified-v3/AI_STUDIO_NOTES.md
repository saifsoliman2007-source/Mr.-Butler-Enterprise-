# Mr. Butler — AI Studio Unified Mobile Project

This project is intentionally a single responsive React application flow for Android and iOS.

## Runtime rules
- There is no desktop/device-preview toolbar in the application UI.
- Android and iOS render the same screen/component tree.
- The application uses responsive CSS rather than separate Android/iOS layouts.
- iOS safe-area and Android system-area insets are handled with `env(safe-area-inset-*)`.
- Navigation uses browser history/hash state so Back works consistently in PWA/WebView environments.
- Touch targets and form controls are mobile-safe.
- Arabic RTL remains supported.
- The application header/navigation belongs to the product UI; preview/debug controls are not rendered.

## AI Studio
Open/import the project as a Vite + React + TypeScript project. The entry point remains:
`src/main.tsx`

The project retains the existing AI Studio server/Gemini integration and all existing Mr. Butler screens, while removing the preview-only device frame and top development toolbar from the runtime.

## Important
Do not create separate Android and iOS screen implementations. Any future platform-specific behavior should be implemented as progressive enhancement inside the shared responsive shell.

## Merge v3 directive
This project is the merged Android+iOS unified version. Keep one shared screen/component/navigation tree. Do not reintroduce TopBar or DeviceFrame into runtime UI.
