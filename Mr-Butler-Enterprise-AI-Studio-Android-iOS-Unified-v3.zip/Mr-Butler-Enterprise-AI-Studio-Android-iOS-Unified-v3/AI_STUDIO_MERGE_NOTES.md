# Mr. Butler — AI Studio Unified Merge v3

This package merges the latest GitHub/AI Studio changes into the previous unified Android+iOS architecture.

## Kept from latest GitHub changes
- Unified BottomNavigationBar.
- Updated service/concierge/orders/foundation routing.
- Browser/mobile history synchronization.
- RTL document language/direction synchronization.
- Responsive safe-area handling.
- New ContentCanvas, DesignSpecsModal and ScreenFlowModal development artifacts.

## Deliberately excluded from runtime
- TopBar/development toolbar and its clock/device controls.
- DeviceFrame simulator component.
- No Android-specific or iOS-specific screen trees.

## Preserved from previous unified version
- Admin feature-toggle drawer.
- Accessibility drawer and live announcements.
- Robust screen parsing for numeric and named ScreenId routes.
- Robust responsive viewport shell and overflow protection.

The application is one shared React flow for Android, iOS, tablet, foldable and web/PWA surfaces.
Do not add platform-specific screen implementations.
