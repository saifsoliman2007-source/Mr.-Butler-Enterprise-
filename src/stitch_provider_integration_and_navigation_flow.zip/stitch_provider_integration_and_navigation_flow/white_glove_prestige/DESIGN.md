---
name: White Glove Prestige
colors:
  surface: '#f8f9ff'
  surface-dim: '#d0daee'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff3ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dfe9fc'
  surface-container-highest: '#d9e3f7'
  on-surface: '#121c2a'
  on-surface-variant: '#40484a'
  inverse-surface: '#273140'
  inverse-on-surface: '#ebf1ff'
  outline: '#70797a'
  outline-variant: '#c0c8ca'
  surface-tint: '#30666f'
  primary: '#002c33'
  on-primary: '#ffffff'
  primary-container: '#00444d'
  on-primary-container: '#7cb0bb'
  inverse-primary: '#9acfda'
  secondary: '#745b00'
  on-secondary: '#ffffff'
  secondary-container: '#ffd65b'
  on-secondary-container: '#755c00'
  tertiary: '#002c30'
  on-tertiary: '#ffffff'
  tertiary-container: '#00444a'
  on-tertiary-container: '#76b1b8'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b5ecf7'
  primary-fixed-dim: '#9acfda'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#124e57'
  secondary-fixed: '#ffe08a'
  secondary-fixed-dim: '#eac24a'
  on-secondary-fixed: '#241a00'
  on-secondary-fixed-variant: '#584400'
  tertiary-fixed: '#b0edf4'
  tertiary-fixed-dim: '#94d1d8'
  on-tertiary-fixed: '#002023'
  on-tertiary-fixed-variant: '#024f55'
  background: '#f8f9ff'
  on-background: '#121c2a'
  surface-variant: '#d9e3f7'
  surface-blue: '#EFF4FF'
  status-online: '#00C896'
typography:
  display-lg:
    fontFamily: Libre Caslon Text
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Libre Caslon Text
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Libre Caslon Text
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  title-md:
    fontFamily: Libre Caslon Text
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-mobile: 1.25rem
  margin-desktop: 5rem
  gutter: 1.5rem
  stack-sm: 0.5rem
  stack-md: 1rem
  stack-lg: 2rem
---

## Brand & Style

The brand identity is built on the concept of "modern heritage." It evokes the meticulous attention to detail of a classic English butler, translated into a seamless, high-efficiency digital experience. The target audience seeks premium convenience and expects a "white-glove" standard of service where every interaction feels curated and professional.

This design system employs a **Corporate / Modern** foundation enriched with **Tactile** and **High-Contrast** elements. It utilizes generous whitespace, deep jewel tones, and serif typography to establish authority, while maintaining a clean, systematic layout that ensures the "efficiency" of the modern service provider. The aesthetic is sophisticated and elite, yet remains accessible through intuitive, functional patterns.

## Colors

The palette is anchored by "Butler Teal" (#00444D), a deep, authoritative emerald that serves as the primary brand color for surfaces and high-level branding. "Signature Gold" (#CCA730) is used sparingly as an accent to denote premium status, highlights, and successful actions.

The background uses a tiered approach: "Surface Blue" (#EFF4FF) provides a soft, cool alternative to pure white, reducing eye strain while maintaining a premium feel. "Midnight Navy" (#121C2A) is reserved for high-contrast typography and deep structural elements. For provider status indicators, a vibrant "Status Green" (#00C896) is used to signal availability with clarity.

## Typography

The typography strategy pairs the historical elegance of **Libre Caslon Text** for headlines and branding with the high-performance legibility of **Hanken Grotesk** for functional UI and body text. 

Headlines should utilize the serif font to reinforce the "butler" theme, using optical sizing and generous line heights to feel airy and prestigious. All body text and data-heavy provider views use the sans-serif for clarity. Functional labels and status indicators should use the sans-serif in medium to semi-bold weights, often with slight tracking increases for better scannability at small sizes.

## Layout & Spacing

This design system utilizes a **Fixed Grid** for desktop views (max-width 1200px) to maintain a centered, editorial look that feels intentional and composed. Mobile layouts transition to a fluid 4-column system with 20px margins.

Spacing follows an 8px base unit. To maintain the "premium" feel, vertical "breathable" space is prioritized—avoiding cramped clusters of information. Information-heavy provider dashboards use more compact spacing (8px-12px) for utility, while consumer-facing landing pages use expansive spacing (32px-64px) to emphasize the brand's calm and composed nature.

## Elevation & Depth

Visual hierarchy is established through **Tonal Layers** and subtle **Ambient Shadows**. Surfaces are primarily flat to maintain a modern edge, but depth is used to separate "service tiers" and "active states."

- **Level 1 (Base):** Surface Blue (#EFF4FF).
- **Level 2 (Cards):** White (#FFFFFF) with a very soft, large-radius shadow (0px 4px 20px rgba(0, 68, 77, 0.05)).
- **Level 3 (Modals/Popovers):** White with a more pronounced shadow and a 1px border in a lighter shade of Teal to define the edge.

Glassmorphism is used exclusively for global navigation bars and sticky headers, using a backdrop blur (12px) and 80% opacity on white to allow underlying content to peek through without sacrificing legibility.

## Shapes

The shape language balances tradition with modernity. A "Rounded" (0.5rem) base is used for most UI components (buttons, input fields, cards) to keep the interface feeling approachable. 

However, specialized branding elements like service category icons or premium badges may use "Pill-shaped" or circular containers to stand out from the structural grid. Heavy structural borders are avoided in favor of subtle background shifts or soft shadows.

## Components

### Buttons
Primary buttons use the "Butler Teal" background with white text and a subtle 2px bottom "border-shadow" for a tactile feel. Secondary buttons use a Teal outline with a transparent background. Special "Premium" actions may utilize a Gold background with Midnight Navy text.

### Input Fields
Inputs are defined by a 1px border in a muted teal/gray. Upon focus, the border thickens to 2px in "Butler Teal" and the label moves into a floating position using the sans-serif font.

### Cards & Status Indicators
Cards are used to group service offerings or order details. They should feature a "white-glove" indicator—a small vertical bar or corner accent in Gold for VIP services. Provider status is displayed as a circular dot (online/offline) or a high-contrast pill label (e.g., "In Transit").

### Lists & Navigation
Navigation uses the serif font for high-level categories and the sans-serif for utility links. The bottom navigation bar on mobile features active-state icons with a subtle gold "dot" indicator above the icon to denote the current section.